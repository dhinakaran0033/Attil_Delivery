package com.develop.sns.listener

interface BrandSelectListener {
    fun onSelection()
}