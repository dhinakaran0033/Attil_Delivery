package com.develop.sns.listener

interface AppUserListener {
    fun selectItem(position: Int)
}